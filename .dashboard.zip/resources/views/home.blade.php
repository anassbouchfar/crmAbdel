@extends('layouts.app')

@section('content')
<h1>Hello Jalal</h1>
@endsection
