<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Appel extends Model
{
    protected $table="appels";
}
