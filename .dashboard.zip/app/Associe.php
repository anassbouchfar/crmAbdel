<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Associe extends Model
{
    protected $table="associes";
}
