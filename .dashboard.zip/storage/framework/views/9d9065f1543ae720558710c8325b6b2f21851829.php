
<?php $__env->startSection('statistique'); ?>
<?php
 

 function age($date)
{
  return (int) ((time() - strtotime($date)) / 3600 / 24 / 365);
}
?>

                      <div class="content-wrapper">
                        <nav class="navbar navbar-expand-lg navbar-light bg-light">
                          <a class="navbar-brand" href="#">Admin</a>
                          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                          </button>
                        
                          <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                              <li class="nav-item active">
                                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Home <span class="sr-only">(current)</span></a>
                              </li>
                              <li class="nav-item">
                                <div class="dropdown show">
                                  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Notification <span class="badge badge-light"><?php $i=0; foreach($notification as $noti)
                                    {
                                      $i=$i+1;
                                    }
                                    echo $i; ?>
          
                                    </span>
                                  </a>
                                
                                  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item" href="#"><?php echo e($noti['nom']); ?> <?php echo e($noti['prenom']); ?> <strong> <?php echo e($noti['status']); ?></strong> </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                  </div>
                                 
                                </div>
                              </li>
                              




                              
                            
                                </form>
                              
                            </ul>
                            <form class="form-inline my-2 my-lg-0" action="<?php echo e(route('cherchertelephone')); ?>">
                              <input name='télephone' class="form-control mr-sm-2" type="search" placeholder="Télephone" aria-label="Search">
                              <button type="submit" class="btn btn-outline-success my-2 my-sm-0" type="submit">chercher</button>
                            </form>
                          </div>
                        </nav>
                      <div class="page-header">
                        <h3 class="page-title">
                          <span class="page-title-icon bg-gradient-primary text-white mr-2">
                            
                            <i class="mdi mdi-home"></i>
                          </span> Dashboard </h3>
                          
                        <nav aria-label="breadcrumb">
                          <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                              <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                          </ul>
                        </nav>
                      </div>
                      
                      <br>
                      
                    <br>
                      <div class='container border'>
                      <div class="row">
                        <form action="<?php echo e(route('statistique')); ?>">
                          <p class="text-monospace">Quelle compagne?</p>
                          <div class="form-check">
                            <input name='a'class="form-check-input" type="checkbox" value="a" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                              A
                            </label>
                          </div>
                          <div class="form-check">
                            <input name='b' class="form-check-input" type="checkbox" value="b" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                              B
                            </label>
                          </div>
                          <div class="form-check">
                            <input name='c' class="form-check-input" type="checkbox" value="c" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                              C
                            </label>
                           
                          </div>
                          <button type='submit' class="btn btn-success">Voir statistique</button>
                          
                          </form>
                      </div>
                    </div>
                      <br>
                      <div class="row">
                        
                        
                        <div class="col-md-3 stretch-card grid-margin" style=" height: 195px;">
                          <div class="card bg-gradient-danger card-img-holder text-white">
                            <div class="card-body">
                              <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                              <h4 class="font-weight-normal mb-2">C.A <i class="mdi mdi-chart-line mdi-24px float-right"></i>
                              </h4>
                              <h2 class="mb-3"><?php echo e($CA); ?>£</h2>
                              <h6 class="card-text">--%</h6>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-2 stretch-card grid-margin" style=" height: 195px;">
                          <div class="card bg-gradient-info card-img-holder text-white">
                            <div class="card-body">
                              <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                              <h4 class="font-weight-normal ">Prime <i class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                              </h4>
                              <h2 class="mb-5"><?php echo e($prime); ?>£</h2>
                              
                            </div>
                          </div>
                        </div>
                        
                        <div class="col-md-2 stretch-card grid-margin " style=" height: 195px;">
                          <div class="card bg-gradient-success card-img-holder text-white">
                            <div class="card-body">
                              <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                              <h4 class="font-weight-normal mb-3">Nombre d'appel<i class="mdi mdi-diamond mdi-24px float-right"></i>
                              </h4>
                            <h2 class="mb-5"><?php echo e($nombre); ?></h2>
                              
                            </div>
                          </div>
                        </div>
                        <div class="col-md-2 stretch-card grid-margin" style=" height: 195px;">
                          <div class="card bg-gradient-success card-img-holder text-white">
                            <div class="card-body">
                              <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                              <h4 class="font-weight-normal mb-3">Taux de Validation<i class="mdi mdi-diamond mdi-24px float-right"></i>
                              </h4>
                            <h4 class="mb-5">A:<?php echo e($ta); ?>%  B:<?php echo e($tb); ?>%  C:<?php echo e($tc); ?>%</h4>
                            
                              
                            </div>
                          </div>
                        </div>
                        <div class="col-md-3 stretch-card grid-margin" style=" height: 195px;">
                            <div class="card bg-gradient-success card-img-holder text-white">
                              <div class="card-body">
                                <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                                <h4 class="font-weight-normal mb-3">Objectif<i class="mdi mdi-diamond mdi-24px float-right"></i>
                                </h4>
                                <h2 class="mb-5">10000£</h2>
                                
                              </div>
                            </div>
                          </div>
                      </div>




<?php $__env->stopSection(); ?>























































<?php $__env->startSection('list'); ?>

<?php if(session()->has('status')): ?>
<h3 style='text-align:center;' class="alert alert-danger" role="alert"><?php echo e(session()->get('status')); ?></h3>
<?php endif; ?>
<div class="row">


<div class="col-sm" style="height:200px;width: 200px;">
        <div class="alert alert-primary" >
          chercher par nom:
        </div>
          <form action="<?php echo e(route('chercher')); ?>">

            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Entrer le nom:</label>
              <input name='nom'type="text" class="form-control" id="recipient-name" >
              <div>
                <div class="modal-footer">
                <button  class="btn btn-success" type="submit"> Trouver</button>
              </div>
              
            </div>

          </form>
          
</div>

</div>
<div class="col-sm">
<div class="alert alert-primary" role="alert">
  veuillez choisir votre status
</div>

<form action="<?php echo e(route('filtrer')); ?>" method='GET'>
<div>
  
  <label value="<?php echo e(old('status')); ?>" for="status">  <strong> Status :</strong> </label>
  <SELECT class="browser-default custom-select" name="status" size="1" >
    <option value="tout">tout</option>
    <option value="nrp">nrp</option>
    <option value="cali">cali</option>
    <option value="refus">refus</option>
    <option value="ok">ok</option>
    <option value="fn">fn</option>
    <option value="doublant">doublant</option>
    <option value="rdv">rdv</option>
    <option value="rappel">rappel</option>
    <option value="promesse">promesse</option>
    <option value="chute">chute</option>
    <option value="non">a ne pas rappeler</option>
    <option value="inj">inj</option>
  </SELECT>
  <div>
  <label for="compagne"><strong> Compagne :</strong></label>
  <SELECT name="compagne" size="1" >
    <option value="a">A</option>
    <option value="b">B</option>
    <option value="c">C</option>
    
  </SELECT>
</div>
</div>
<div class="modal-footer">
    <button  class="btn btn-success" type="submit"> chercher</button>
</div>   
</form>
                      </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('telephone'); ?>

 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
           
<td>
                                      <?php echo e($client->civilité); ?> 
                                       
                                      </td>
                                      <script>

                                        $('.popover-dismiss').popover({
                                          trigger: 'focus'
                                        })
                                                                                  </script>
                                      <td> <?php echo e($client->nom); ?> </td>
                                      <td> <?php echo e($client->prénom); ?> </td>
                                      <td> <?php echo e($client->email); ?> </td>
                                      <td> <?php echo e($client->télephone); ?> </td>
                                      <td> <?php echo e($client->cotisation); ?> </td>
                                      <td > 
                                        <?php if($client->status=="nrp"): ?>
                                        <p style='background-color: #FFD700; text-align:center;'> <strong> nrp</strong>  </p>
                                        
                                          
                                        
                                        <?php endif; ?>
                                        <?php if($client->status=="cali"): ?>
                                        <p style='background-color: #DCDCDC; text-align:center;'>  <strong> cali</strong>  </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="refus"): ?>
                                        <p style='background-color: #FF69B4; text-align:center;'> <strong> refus</strong>  </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="ok"): ?>
                                        <p style='background-color: #008000; text-align:center;'> <strong> ok</strong>  </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="fn"): ?>
                                        <p style='background-color: #000000; text-align:center;'> <strong> fn</strong>  </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="doublant"): ?>
                                        <p > doublant </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="rdv"): ?>
                                        <button type="button" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title=<?php echo e($client->date_status); ?>>
                                          rdv
                                        </button>
                                        <?php endif; ?>
                                        <?php if($client->status=="rappel"): ?>
                                        <button type="button" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title=<?php echo e($client->date_status); ?>>
                                          rappel
                                        </button>
                                        <?php endif; ?>
                                        <?php if($client->status=="promesse"): ?>
                                        <button type="button" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title=<?php echo e($client->date_status); ?>>
                                          promesse
                                        </button>
                                        <?php endif; ?>
                                        <?php if($client->status=="a ne pas rappeler"): ?>
                                        <p style='background-color: #000000; text-align:center;'> <strong> à ne pas rappeler</strong> </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="chute"): ?>
                                        <p style='background-color: #000000; text-align:center;'> <strong> chute</strong>  </p>
                                        <?php endif; ?>
                                        <?php if($client->status=="inj"): ?>
                                        <p style='background-color: red; text-align:center;'> inj </p>
                                        <?php endif; ?>

                                        
                                        
                                         </td>
                                         <td><?php echo e($client->régime); ?></td>
                                      <td> 

                                        <?php $__currentLoopData = $assurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($client->assurance_actuelle==$assurance->id): ?>
                                                        <?php echo e($assurance->assurance); ?>

                                                       
                                                        <?php endif; ?>

                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                      </td>
                                      <td> 
                                        <?php $__currentLoopData = $assurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($client->assurance_vendu==$assurance->id): ?>
                                        <?php echo e($assurance->assurance); ?>

                                       
                                        <?php endif; ?>

                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                      
                                      
                                      </td>
                                      <td> 
                                        <form method='GET' action=<?php echo e(route('add_commentaire')); ?>>
                                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($client->nom); ?><?php echo e($client->prénom); ?><?php echo e($client->id); ?>" data-whatever="@mdo">Commentaire</button>
                                        <div class="modal fade" id=<?php echo e($client->nom); ?><?php echo e($client->prénom); ?><?php echo e($client->id); ?> tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document" >
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Commentaire</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                               
                                              </div>
                                              <div class="alert alert-primary" style='text-align:center;'role="alert">
                                                Nom et Prénom :<a href="#" class="alert-link"><?php echo e($client->nom); ?> <?php echo e($client->prénom); ?></a>
                                               </div>
                                              <div class="modal-body">
                                                <?php $__currentLoopData = $commentaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php if($commentaire->client_id==$client->id): ?>
                                                  
                                                  <div class="form-group">
                                                  <label for="message-text" class="col-form-label">le:<?php echo e($commentaire->created_at); ?></label>
                                                    <label class="form-control" id="message-text"> <?php echo e($commentaire->commentaire); ?></label>
                                                    
                                                  </div>
                                                  <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                              <input name='id' type="hidden" value=<?php echo e($client->id); ?>>
                                              <div class="form-group">
                                                <label for="message-text" class="col-form-label"><strong> Nouveau Commentaire</strong></label>
                                                  <textarea name='commentaire' class="form-control" id="message-text"></textarea>
                                                </div>
                                              </div>
                                              <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Ajouter</button>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </form>
                                      
                                      
                                      
                                      
                                      </td>
                                      <td> <?php echo e($client->ville); ?> </td>
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      
                                      <td>
                                        <form action='<?php echo e(route('update')); ?>' method='GET'>
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($client->nom); ?><?php echo e($client->prénom); ?>" data-whatever="@getbootstrap">Ouvrir</button>
                                        <div class="modal fade" id=<?php echo e($client->nom); ?><?php echo e($client->prénom); ?> tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document" style='margin-left: 359px;'>

                                            <div class="modal-content" style="width: 720px;">
                                              <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel"> Client : <?php echo e($client->nom); ?> <?php echo e($client->prénom); ?></h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                              </div>
                                              <div class="modal-body">
                                                <input name='id'type="hidden" class="form-control" id="recipient-name" value=<?php echo e($client->id); ?>>
                                                <div class="form-row">
                                                  <div class="form-group col-md-6">
                                                    <label for="inputEmail4">nom</label>
                                                    <input name="nom"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->nom); ?>>
                                                  </div>
                                                  <div class="form-group col-md-6">
                                                    <label for="inputPassword4">Prénom</label>
                                                    <input name="prénom"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->prénom); ?>>
                                                  </div>
                                                </div>
                                                <div class="form-group">
                                                  <label for="inputAddress">Addresse</label>
                                                  <input name="adresse"type="text" class="form-control" id="inputAddress" placeholder="adresse" value=<?php echo e($client->adresse); ?>>
                                                </div>
                                                
                                                <div class="form-row">
                                                  <div class="form-group col-md-6">
                                                    <label for="inputCity">Ville</label>
                                                    <input name="ville"type="text" class="form-control" id="inputCity" value=<?php echo e($client->ville); ?>>
                                                  </div>
                                                  
                                                  <div class="form-group col-md-2">
                                                    <label for="inputZip">Zip</label>
                                                    <input name="codepostal"type="text" class="form-control" id="inputZip" value=<?php echo e($client->codepostal); ?>>
                                                  </div>
                                                  <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                      <label for="inputEmail4">Date Naissance</label>
                                                      <input name="date_naissance"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->date_naissance); ?>>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                      <label for="inputPassword4">Age</label>
                                                      <input name="age"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo age($client->date_naissance); ?> disabled>
                                                    </div>
                                                  </div>
                                                </div>
                                                
                                                  
                                                
                                                  <div class="form-group">
                                                    <label for="recipient-name" class="col-form-label">email:</label>
                                                    <input name='email'type="text" class="form-control" id="recipient-name"  value=<?php echo e($client->email); ?>> 
                                                  </div>



                                                  <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                      <label for="inputEmail4">Cotisation</label>
                                                      <input name="cotisation"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->cotisation); ?>>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                      <label for="inputPassword4">Status Actuelle</label>
                                                      
                                                      <?php if($client->status=="rappel" || $client->status=="rdv" || $client->status=="promesse"): ?>
                                                      <input type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->status); ?><?php echo e($client->date_status); ?> disabled>
                                                    
                                                    <?php else: ?>
                                                    <input type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->status); ?> disabled >
                                                    <?php endif; ?>
                                                    </div>
                                                  </div>
                                               
                                                  
                                                  <div class="form-group">
                                                    
                                                    <label for="recipient-name" class="col-form-label">Changer status :</label><br>
                                                    <SELECT class="browser-default custom-select" name="status" size="1" >
                                                      
                                                      <option value="nrp">nrp</option>
                                                      <option value="cali">cali</option>
                                                      <option value="refus">refus</option>
                                                      <option value="ok">ok</option>
                                                      <option value="fn">fn</option>
                                                      <option value="doublant">doublant</option>
                                                      <option value="rdv">rdv</option>
                                                      <option value="rappel">rappel</option>
                                                      <option value="promesse">promesse</option>
                                                      <option value="chute">chute</option>
                                                      <option value="non">a ne pas rappeler</option>
                                                      <option value="inj">inj</option>
                                                    </SELECT>
                                                  </div>
                                                  
                                                  <div class="form-group">
                                                    <label for="recipient-name" class="col-form-label"> <strong> Assurance vendu: </strong> </label>
                                                    
                                                    <br>
                                                    
                                                    <SELECT class="browser-default custom-select" name="assurance_vendu" size="1" >
                                                      
                                                      <?php $__currentLoopData = $assurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($client->assurance_vendu==$assurance->id): ?>
                                                        <option selected value=<?php echo e($assurance->id); ?>><?php echo e($assurance->assurance); ?></option>
                                                        <?php else: ?>
                                                        <option  value=<?php echo e($assurance->id); ?>><?php echo e($assurance->assurance); ?></option>
                                                        <?php endif; ?>

                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                                    </SELECT>


















                                                  </div>
                                                  <div class="form-group">
                                                    <label for="recipient-name" class="col-form-label"> <strong>Assurance actuelle:</strong></label>
                                                    <br>
                                                    <SELECT class="browser-default custom-select" name="assurance_actuelle" size="1" >
                                                      
                                                      <?php $__currentLoopData = $assurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($client->assurance_actuelle==$assurance->id): ?>
                                                        <option selected value=<?php echo e($assurance->id); ?>><?php echo e($assurance->assurance); ?></option>
                                                        <?php else: ?>
                                                        <option  value=<?php echo e($assurance->id); ?>><?php echo e($assurance->assurance); ?></option>
                                                        <?php endif; ?>

                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                                    </SELECT>

                                                  </div>
                                                  <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                      <label for="inputEmail4">IBAN</label>
                                                      <input name="iban"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->iban); ?>>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                      <label for="inputPassword4">Sécurité Sociale</label>
                                                      <input name="ss"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->ss); ?>>
                                                    </div>
                                                  </div>
                                                  
                                                  <div class="form-group">
                                                    <label for="recipient-name" class="col-form-label">Régime:</label>
                                                    <input name='regime' type="text" class="form-control" id="recipient-name" value=<?php echo e($client->régime); ?> >
                                                  </div>
                                                  <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                      <label for="inputEmail4">Télephone</label>
                                                      <input name="telephone"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->télephone); ?>>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                      <label for="inputPassword4">Télephone 1</label>
                                                      <input name="telephone1"type="" class="form-control" id="inputEmail4" placeholder="nom" value=<?php echo e($client->télephone1); ?>>
                                                    </div>
                                                  </div>
                                                  <div>
                                                    
                                                  
                                                  </div>
                                                  <!--div class="modal-footer"-->
                                                    <!--button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button-->
                                                    <button type='submit' class="btn btn-primary">Enregistrer</button>
                                                  </div>
                                                </form>
                                              </div>
                                              
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                      <td>
                                      <form action="<?php echo e(route('add_associe')); ?>">
                                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($client->nom); ?><?php echo e($client->prénom); ?><?php echo e($client->nom); ?>">
                                            +
                                          </button>
                                          <div class="modal fade" id=<?php echo e($client->nom); ?><?php echo e($client->prénom); ?><?php echo e($client->nom); ?> tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                <div class="modal-header">
                                                  <h5 class="modal-title" id="exampleModalLabel">Ajouter Associé à <?php echo e($client->nom); ?> <?php echo e($client->prénom); ?></h5>
                                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                  </button>
                                                </div>
                                                <div class="modal-body">
                                                  <div class="form-row">
                                                    <div class="form-group col-md-4">
                                                      <label for="inputPassword4">Civilité</label>
                                                      <select  name="civilité_associe"class="form-control form-control-sm">
                                                        <option>Mr</option>
                                                        <option>Mme</option>
                                                      </select>

                                                    </div>
                                                    <div class="form-group col-md-4">
                                                      <label for="inputEmail4">Nom</label>
                                                      <input name="nom_associe"type="" class="form-control" id="inputEmail4" placeholder="nom" value="">
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                      <label for="inputPassword4">Prénom</label>
                                                      <input name="prenom_associe"type="" class="form-control" id="inputEmail4" placeholder="nom" value="">
                                                    </div>
                                                  </div>
                                                  <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                      <label for="inputEmail4">Sécurité Sociale</label>
                                                      <input name="ss_associe"type="" class="form-control" id="inputEmail4" placeholder="nom" value="">
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                      <label for="inputPassword4">Régime</label>
                                                      <input name="regime_associe"type="" class="form-control" id="inputEmail4" placeholder="nom" value="">
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="modal-footer">
                                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                  <button type="sumbit" class="btn btn-primary">Save changes</button>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </form>
                                      </td>
                                    

                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                      




                                    





                                  </tr>   
                                  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
                                  <script>
                                    $(()=>{
                                      $(".addChild").click(()=>{
                                        str =' <div class="form-row">\
                                                                                    <div class="form-group col-md-6">\
                                                                                      <label for="inputEmail4">nom</label>\
                                                                                      <input name="iban"type="" class="form-control" id="inputEmail4" placeholder="nom" >\
                                                                                    </div>\
                                                                                    <div class="form-group col-md-6">\
                                                                                      <label for="inputPassword4">prénom</label>\
                                                                                      <input name="ss"type="" class="form-control" id="inputEmail4" placeholder="nom" >\
                                                                                    </div>\
                                                                                  </div>\
                                                                                  <div class="form-row">\
                                                                                    <div class="form-group col-md-6">\
                                                                                      <label for="inputEmail4">IBAN</label>\
                                                                                      <input name="iban"type="" class="form-control" id="inputEmail4" placeholder="nom" >\
                                                                                    </div>\
                                                                                    <div class="form-group col-md-6">\
                                                                                      <label for="inputPassword4">Sécurité Sociale</label>\
                                                                                      <input name="ss"type="" class="form-control" id="inputEmail4" placeholder="nom" >\
                                                                                    </div>\
                                                                                    <div class="form-group col-md-6">\
                                                                                    <label for="inputPassword4">Régime</label>\
                                                                                    <input name="ss"type="" class="form-control" id="inputEmail4" placeholder="nom" >\
                                                                                  </div>\
                                                                                  </div>'
                                                                                  
                                        $(".contChilds").append(str)
                                      })
                                    })
                                  </script>
                                  
                                  
                                 
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      

<?php $__env->stopSection(); ?>

<?php echo $__env->make('herite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dashboard\resources\views/dashboard.blade.php ENDPATH**/ ?>